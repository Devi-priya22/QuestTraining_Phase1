﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Entities.Types
{
    public enum EmploymentType
    {
        FullTime,
        Contract
    }
}
